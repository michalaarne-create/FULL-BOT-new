cd "E:\BOT ANK\bot\moje_AI"
scripts/activate
cd "E:\BOT ANK\bot\moje_AI\yolov8\FULL BOT"
& "E:\miniconda3\condabin\conda.bat" activate ai_cuda
python workflow/app.py
Read-Host "Naciśnij Enter, żeby zamknąć okno"
